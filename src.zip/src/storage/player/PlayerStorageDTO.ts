export type PlayerStorageDTO = {
    name: string;
    team: string;
}