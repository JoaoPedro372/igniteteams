const GROUP_COLLECTION = '@ignite-teams: groups'
const PLAYER_COLLECTION = '@ignite-teams: players'


export { GROUP_COLLECTION, PLAYER_COLLECTION };